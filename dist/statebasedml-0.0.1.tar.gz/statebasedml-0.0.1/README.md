# State Based Machine Learning
statebasedml is a Python library for training data on state based machine learning data. 
